from distutils.core import setup

setup(
		name = 'nester_list',
		version = '1.0.0',
		py_modules = ['nester_list'],
		author = 'Govardhan',
		author_email = 'kartheekravulamtech@gmail.com',
		url = 'gmksoftware.blogspot.com',
		description = 'A simple printer of nested lists',
	)